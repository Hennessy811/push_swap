/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cskeleto <cskeleto@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/05/20 19:50:07 by cskeleto          #+#    #+#             */
/*   Updated: 2019/05/20 19:50:07 by cskeleto         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	push_swap(int ac, char **av)
{
	t_root	*root;

	ft_read(ac, av, &root);
	sort(&root);
}

int		main(int ac, char **av)
{
	if (ac > 1)
		push_swap(ac, &av[1]);
	return (0);
}
